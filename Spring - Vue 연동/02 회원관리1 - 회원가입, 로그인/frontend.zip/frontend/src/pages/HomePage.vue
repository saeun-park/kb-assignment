<script setup></script>

<template>
  <h1>첫 페이지입니다.</h1>
  여기가 렌더링 들어가
  <hr />
  <img
    src="https://cdn.pixabay.com/photo/2017/01/31/15/24/face-2025030_960_720.png"
  />
</template>

<style scoped></style>
