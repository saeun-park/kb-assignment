package org.scoula.config;

public class RootConfig {
}
