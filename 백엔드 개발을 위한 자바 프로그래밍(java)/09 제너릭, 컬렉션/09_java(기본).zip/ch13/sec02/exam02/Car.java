package ch13.sec02.exam02;

public class Car {
    public void run(){
        System.out.println("자동차가 달립니다.");
    }
}
