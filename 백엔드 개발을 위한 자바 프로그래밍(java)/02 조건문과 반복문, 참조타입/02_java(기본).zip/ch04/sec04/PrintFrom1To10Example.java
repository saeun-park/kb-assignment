package ch04.sec04;

public class PrintFrom1To10Example {
    public static void main(String[] args) {

        for(int i=0; i<10; i++){

            System.out.print(i+1 + " ");
        }
    }
}

//import java.util.Arrays;
//public class PrintFrom1To10Example {
//    public static void main(String[] args) {
//        int[] arr = new int[10];
//        for(int i=0; i<10; i++){
//            arr[i] = i+1;
//
//        }
//        System.out.println(Arrays.toString(arr));
//    }
//}