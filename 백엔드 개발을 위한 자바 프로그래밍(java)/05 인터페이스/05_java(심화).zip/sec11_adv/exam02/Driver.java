package ch08.sec11_adv.exam02;

public class Driver {
    void drive(Vehicle vehicle){
        vehicle.run();
    }
}
