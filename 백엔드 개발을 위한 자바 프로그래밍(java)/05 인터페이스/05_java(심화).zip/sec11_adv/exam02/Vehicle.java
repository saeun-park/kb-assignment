package ch08.sec11_adv.exam02;

public interface Vehicle {
    void run();
}
