package ch08.sec11_adv.exam01;

public interface Tire {
    void roll();
}
