package ch08.sec12_adv;

public interface Vehicle {
    void run();
}
