package ch08.sec02;

public interface RemoteControl {
//    public void turnOn();
    void turnOn();
}
