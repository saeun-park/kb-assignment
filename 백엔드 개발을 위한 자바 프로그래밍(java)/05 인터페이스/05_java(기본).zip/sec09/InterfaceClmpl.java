package ch08.sec09;

public class InterfaceClmpl implements InterfaceC{
    public void methodA(){
        System.out.println("InterfaceClmpl-methodA() 실행");
    }
    public void methodB(){
        System.out.println("InterfaceClmpl-methodB() 실행");
    }
    public void methodC(){
        System.out.println("InterfaceClmpl-methodC() 실행");
    }
}
