package ch08.sec09;

public interface InterfaceB {
    void methodB();
}
