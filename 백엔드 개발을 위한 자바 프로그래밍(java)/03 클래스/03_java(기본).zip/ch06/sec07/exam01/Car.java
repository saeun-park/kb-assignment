package ch06.sec07.exam01;
public class Car {
    // 필드 선언
    String model;
    String color;
    int maxSpeed;

    // 생성자는 클래스와 이름이 같아야 함, 리턴 타입 없음
    public Car(String model, String color, int maxSpeed) {
    }
}

