package ch16.sec05.exam01;

public interface Calculable {
    double calc(double x, double y);
}
