package ch01.sec11;

public class Calculator {
    public static void main(String[] args) {
        int x = 1;
        int y = 2;
        int result = x + y;
        System.out.println(result);
    }

    }
