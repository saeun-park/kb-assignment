package ch02.sec06;

public class StringExample {
    public static void main(String[] args) {
        // 변수 선언 및 초기화
        String name = "홍길동";
        String job = "프로그래머";
//        String lang = "자바";

        // 변수 출력
        System.out.println("이름: " + name);
        System.out.println("직업: " + job);
//        System.out.println("나는 " + lang + "를 배웁니다.");
        System.out.println("나는 \"자바\"를 배웁니다.");
        System.out.println("번호\t이름\t직업");
        System.out.println("나는");
        System.out.println("자바를");
        System.out.println("배웁니다.");
    }
}
