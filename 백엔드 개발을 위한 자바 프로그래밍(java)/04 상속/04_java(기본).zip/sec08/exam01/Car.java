package ch07.sec08.exam01;

public class Car {
    public Tire tire;
    public void run(){
        tire.roll();
    }
}
