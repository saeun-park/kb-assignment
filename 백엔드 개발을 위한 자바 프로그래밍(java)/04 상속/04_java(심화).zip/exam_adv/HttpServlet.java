package ch07.exam_adv;

public abstract class HttpServlet {

    public abstract void service();
}
