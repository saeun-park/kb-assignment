package ch07.exam_adv;

public class LoginServlet extends HttpServlet{
    @Override
    public void service() {
        System.out.println("로그인 합니다.");
    }
}
